<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Just do it
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2014-2019 </strong> 
  </footer>
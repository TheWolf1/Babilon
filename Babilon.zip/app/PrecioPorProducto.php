<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PrecioPorProducto extends Model
{
    //
    protected $table = 'precio_x_producto';
}
